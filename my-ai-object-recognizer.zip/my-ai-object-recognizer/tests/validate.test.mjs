import test from 'node:test';
import assert from 'node:assert/strict';
import { checkImageSize, inspectImage, isValidSampleId, makeVersionId, isValidVersion, passesAccuracyGate, sha256Hex, validateCategoryName, validateModelArtifacts } from '../netlify/lib/validate.mjs';
import { makeJpeg, makeModel, makePng } from './helpers/fixtures.mjs';

test('category names: good, messy and bad', () => {
  assert.deepEqual(validateCategoryName('  Water   Bottle '), { ok: true, name: 'Water Bottle', slug: 'water-bottle' });
  assert.equal(validateCategoryName('Pen_2').slug, 'pen-2');
  for (const bad of ['', '   ', '../etc', 'a/b', '<b>x</b>', 'x'.repeat(41), '-lead', 'বই', 'Unknown', 42, null]) {
    assert.equal(validateCategoryName(bad).ok, false, `should reject ${String(bad)}`);
  }
});

test('image inspection reads real bytes', () => {
  assert.deepEqual(inspectImage(makeJpeg(300, 200)), { ok: true, type: 'image/jpeg', width: 300, height: 200 });
  assert.deepEqual(inspectImage(makePng(128, 64)), { ok: true, type: 'image/png', width: 128, height: 64 });
  assert.equal(inspectImage(new TextEncoder().encode('<html>not an image at all, just text</html>')).ok, false);
  assert.equal(inspectImage(new Uint8Array(10)).ok, false);
  assert.equal(inspectImage(new Uint8Array([0xff, 0xd8, 0xff, 0xd9, ...new Array(30).fill(0)])).ok, false);
});

test('image size limits', () => {
  assert.equal(checkImageSize({ width: 640, height: 480 }).ok, true);
  assert.equal(checkImageSize({ width: 10, height: 480 }).ok, false);
  assert.equal(checkImageSize({ width: 9000, height: 480 }).ok, false);
});

test('ids and versions', async () => {
  const id = await sha256Hex(new Uint8Array([1, 2, 3]));
  assert.equal(isValidSampleId(id), true);
  assert.equal(isValidSampleId('../../x'), false);
  assert.equal(isValidVersion(makeVersionId()), true);
  assert.equal(isValidVersion('../active'), false);
});

test('accuracy gate', () => {
  assert.equal(passesAccuracyGate({ evaluatedOn: 'held-out', accuracy: 0.8 }).ok, true);
  assert.equal(passesAccuracyGate({ evaluatedOn: 'held-out', accuracy: 0.5 }).ok, false);
  assert.equal(passesAccuracyGate({ evaluatedOn: 'training', accuracy: 0.8 }).ok, false);
  assert.equal(passesAccuracyGate({ evaluatedOn: 'training', accuracy: 0.95 }).ok, true);
  assert.equal(passesAccuracyGate({ evaluatedOn: 'magic', accuracy: 1 }).ok, false);
  assert.equal(passesAccuracyGate({ evaluatedOn: 'held-out', accuracy: NaN }).ok, false);
  assert.equal(passesAccuracyGate(null).ok, false);
});

test('model validation accepts the three topology shapes TensorFlow.js can produce', () => {
  for (const style of ['array', 'layers', 'wrapped']) {
    const m = makeModel({ style });
    const r = validateModelArtifacts(m.artifacts, m.weightBytes, { labelCount: 2, featureSize: 32 });
    assert.equal(r.ok, true, `${style}: ${r.error}`);
  }
});

test('model validation rejects bad models', () => {
  const ctx = { labelCount: 2, featureSize: 32 };
  const good = () => makeModel();

  let m = good();
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes.slice(4), ctx).ok, false, 'wrong byte size');

  m = good();
  new DataView(m.weightBytes.buffer).setFloat32(0, NaN, true);
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, ctx).ok, false, 'NaN weight');

  m = good();
  new DataView(m.weightBytes.buffer).setFloat32(8, 1e9, true);
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, ctx).ok, false, 'huge weight');

  m = good();
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, { labelCount: 3, featureSize: 32 }).ok, false, 'label mismatch');

  m = good();
  m.artifacts.modelTopology.config.splice(1, 0, { class_name: 'Lambda', config: { function: 'evil()' } });
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, ctx).ok, false, 'Lambda layer');

  m = good();
  m.artifacts.weightSpecs[0].dtype = 'int32';
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, ctx).ok, false, 'dtype');

  m = good();
  m.artifacts.modelTopology.config[2].config.activation = 'linear';
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, ctx).ok, false, 'not softmax');

  m = good();
  m.artifacts.weightSpecs.pop();
  assert.equal(validateModelArtifacts(m.artifacts, m.weightBytes, ctx).ok, false, 'missing tensor');
});
