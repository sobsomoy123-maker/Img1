// Builds tiny fake-but-valid image headers and model files for the tests.
export function makeJpeg(width, height, seed = 0) {
  const head = [
    0xff, 0xd8,
    0xff, 0xe0, 0x00, 0x10, 0x4a, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x00, 0x00, 0x01, 0x00, 0x01, 0x00, 0x00,
    0xff, 0xc0, 0x00, 0x11, 0x08, height >> 8, height & 255, width >> 8, width & 255,
    0x03, 0x01, 0x22, 0x00, 0x02, 0x11, 0x01, 0x03, 0x11, 0x01,
  ];
  const body = [seed & 255, (seed >> 8) & 255, (seed >> 16) & 255, 1, 2, 3];
  return new Uint8Array([...head, ...body, 0xff, 0xd9]);
}

export function makePng(width, height) {
  const b = new Uint8Array(40);
  b.set([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 13, 0x49, 0x48, 0x44, 0x52]);
  const view = new DataView(b.buffer);
  view.setUint32(16, width);
  view.setUint32(20, height);
  return b;
}

const dense = (units, activation) => ({
  class_name: 'Dense',
  config: {
    units, activation, use_bias: true,
    kernel_initializer: { class_name: 'GlorotUniform', config: { seed: null } },
    bias_initializer: { class_name: 'Zeros', config: {} },
    kernel_regularizer: { class_name: 'L1L2', config: { l1: 0, l2: 0.001 } },
  },
});

/** A model in the same shape TensorFlow.js produces: Dense -> Dropout -> Dense(softmax). */
export function makeModel({ featureSize = 32, hidden = 8, labels = 2, style = 'array' } = {}) {
  const layers = [dense(hidden, 'relu'), { class_name: 'Dropout', config: { rate: 0.3 } }, dense(labels, 'softmax')];
  const modelTopology =
    style === 'array' ? { class_name: 'Sequential', config: layers, keras_version: 'tfjs-layers 4.22.0', backend: 'tensor_flow.js' }
    : style === 'layers' ? { class_name: 'Sequential', config: { name: 'sequential_1', layers } }
    : { model_config: { class_name: 'Sequential', config: layers } };
  const weightSpecs = [
    { name: 'dense_Dense1/kernel', shape: [featureSize, hidden], dtype: 'float32' },
    { name: 'dense_Dense1/bias', shape: [hidden], dtype: 'float32' },
    { name: 'dense_Dense2/kernel', shape: [hidden, labels], dtype: 'float32' },
    { name: 'dense_Dense2/bias', shape: [labels], dtype: 'float32' },
  ];
  const count = featureSize * hidden + hidden + hidden * labels + labels;
  const floats = new Float32Array(count).map((_, i) => Math.sin(i) * 0.1);
  const weightBytes = new Uint8Array(floats.buffer.slice(0));
  return { artifacts: { modelTopology, weightSpecs, format: 'layers-model', generatedBy: 'test' }, weightBytes, featureSize, labels };
}

export const toBase64 = (bytes) => Buffer.from(bytes).toString('base64');
