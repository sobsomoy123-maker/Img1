// A tiny in-memory stand-in for Netlify Blobs, used only by the tests.
function makeStore() {
  const data = new Map();
  const asText = (v) => (typeof v === 'string' ? v : new TextDecoder().decode(v));
  const asBuffer = (v) => (typeof v === 'string' ? new TextEncoder().encode(v).buffer : v.slice(0));
  return {
    async set(key, value, options = {}) {
      data.set(key, { value: typeof value === 'string' ? value : value.slice(0), metadata: options.metadata ?? {} });
    },
    async setJSON(key, value) {
      data.set(key, { value: JSON.stringify(value), metadata: {} });
    },
    async get(key, { type = 'text' } = {}) {
      const hit = data.get(key);
      if (!hit) return null;
      if (type === 'json') return JSON.parse(asText(hit.value));
      if (type === 'arrayBuffer') return asBuffer(hit.value);
      return asText(hit.value);
    },
    async getWithMetadata(key, { type = 'text' } = {}) {
      const hit = data.get(key);
      if (!hit) return null;
      return { data: await this.get(key, { type }), etag: 'etag', metadata: hit.metadata };
    },
    async delete(key) {
      data.delete(key);
    },
    async list({ prefix = '' } = {}) {
      const blobs = [...data.keys()].filter((k) => k.startsWith(prefix)).map((key) => ({ key, etag: 'etag' }));
      return { blobs, directories: [] };
    },
  };
}

export function createMemoryBlobs() {
  const stores = new Map();
  return (name) => {
    if (!stores.has(name)) stores.set(name, makeStore());
    return stores.get(name);
  };
}
