// Runs the real Netlify Function code against an in-memory fake of Netlify Blobs.
import test from 'node:test';
import assert from 'node:assert/strict';
import { RATE_LIMITS } from '../netlify/lib/config.mjs';
import { setStoreFactory } from '../netlify/lib/storage.mjs';
import saveSample from '../netlify/functions/save-sample.mjs';
import listSamples from '../netlify/functions/list-samples.mjs';
import getSample from '../netlify/functions/get-sample.mjs';
import trainingLock from '../netlify/functions/training-lock.mjs';
import saveModel from '../netlify/functions/save-model.mjs';
import getModel from '../netlify/functions/get-model.mjs';
import deleteData from '../netlify/functions/delete-data.mjs';
import { createMemoryBlobs } from './helpers/memory-store.mjs';
import { makeJpeg, makeModel, toBase64 } from './helpers/fixtures.mjs';

setStoreFactory(createMemoryBlobs());
let ipCounter = 0;
const ctx = () => ({ ip: `10.0.0.${++ipCounter}` }); // a fresh visitor for each call
const base = 'http://localhost';
const post = (path, body, headers = {}) =>
  new Request(base + path, { method: 'POST', body, headers });
const postJson = (path, obj, headers = {}) => post(path, JSON.stringify(obj), { 'content-type': 'application/json', ...headers });

async function upload(category, seed, w = 120, h = 100) {
  return saveSample(post(`/api/save-sample?category=${encodeURIComponent(category)}`, makeJpeg(w, h, seed)), ctx());
}

test('uploads: validation, storage and duplicates', async () => {
  assert.equal((await upload('../hack', 1)).status, 400);
  assert.equal((await saveSample(post('/api/save-sample?category=Bottle', 'just text, not an image file at all'), ctx())).status, 415);
  assert.equal((await upload('Bottle', 1, 20, 20)).status, 422);
  assert.equal((await saveSample(post('/api/save-sample?category=Bottle', new Uint8Array(0)), ctx())).status, 400);
  assert.equal((await saveSample(new Request(base + '/api/save-sample?category=Bottle'), ctx())).status, 405);
  const big = new Uint8Array(1_600_000); big.set(makeJpeg(100, 100));
  assert.equal((await saveSample(post('/api/save-sample?category=Bottle', big), ctx())).status, 413);

  const first = await upload('Water Bottle', 1);
  assert.equal(first.status, 201);
  const body = await first.json();
  assert.equal(body.category.slug, 'water-bottle');
  assert.equal(body.category.count, 1);

  const again = await upload('water-bottle', 1); // same picture, different spelling of the name
  assert.equal(again.status, 200);
  assert.equal((await again.json()).duplicate, true);

  for (const seed of [2, 3]) assert.equal((await upload('Water Bottle', seed)).status, 201);
  for (const seed of [11, 12, 13]) assert.equal((await upload('Book', seed)).status, 201);
});

test('list and read images', async () => {
  const res = await listSamples(new Request(base + '/api/list-samples'), ctx());
  const data = await res.json();
  assert.equal(data.totalSamples, 6);
  assert.deepEqual(data.categories.map((c) => [c.name, c.count]), [['Book', 3], ['Water Bottle', 3]]);
  const cat = data.categories[1];
  const img = await getSample(new Request(`${base}/api/get-sample?category=${cat.slug}&id=${cat.sampleIds[0]}`), ctx());
  assert.equal(img.status, 200);
  assert.equal(img.headers.get('content-type'), 'image/jpeg');
  assert.ok((await img.arrayBuffer()).byteLength > 20);
  for (const bad of ['category=../x&id=' + cat.sampleIds[0], `category=${cat.slug}&id=../../active.json`, 'category=book&id=' + 'a'.repeat(64)]) {
    const r = await getSample(new Request(`${base}/api/get-sample?${bad}`), ctx());
    assert.ok([400, 404].includes(r.status), `${bad} -> ${r.status}`);
  }
});

test('model: lock, validation, versioning, active pointer', async () => {
  const lockA = await (await trainingLock(postJson('/api/training-lock', { action: 'acquire' }), ctx())).json();
  assert.equal(lockA.ok, true);
  const lockB = await trainingLock(postJson('/api/training-lock', { action: 'acquire' }), ctx());
  assert.equal(lockB.status, 409, 'second trainer must wait');

  const m = makeModel({ featureSize: 32, hidden: 8, labels: 2 });
  const payload = (over = {}) => ({
    lockToken: lockA.token, baseVersion: null, labels: ['book', 'water-bottle'], featureSize: 32,
    metrics: { evaluatedOn: 'held-out', accuracy: 0.9, heldOutSamples: 4, trainSamples: 20, epochs: 80 },
    modelArtifacts: m.artifacts, weightsBase64: toBase64(m.weightBytes), ...over,
  });
  const send = (obj) => saveModel(postJson('/api/save-model', obj), ctx());

  assert.equal((await send(payload({ lockToken: 'f'.repeat(32) }))).status, 409, 'wrong lock');
  assert.equal((await send(payload({ baseVersion: 'x' }))).status, 409, 'wrong base version');
  assert.equal((await send(payload({ labels: ['book', 'ghost'] }))).status, 409, 'unknown category');
  assert.equal((await send(payload({ labels: ['book', '../x'] }))).status, 400, 'bad slug');
  assert.equal((await send(payload({ metrics: { evaluatedOn: 'held-out', accuracy: 0.4 } }))).status, 422, 'low accuracy');
  const nan = new Uint8Array(m.weightBytes); new DataView(nan.buffer).setFloat32(0, NaN, true);
  assert.equal((await send(payload({ weightsBase64: toBase64(nan) }))).status, 422, 'NaN weights');
  const empty = await getModel(new Request(base + '/api/get-model'), ctx());
  assert.equal((await empty.json()).model, null, 'failed saves must not create an active model');

  const ok = await send(payload());
  assert.equal(ok.status, 201);
  const { version } = await ok.json();

  const info = (await (await getModel(new Request(base + '/api/get-model'), ctx())).json()).model;
  assert.equal(info.version, version);
  assert.deepEqual(info.classes.map((c) => c.name), ['Book', 'Water Bottle']);
  const w = await getModel(new Request(base + info.weightsUrl), ctx());
  assert.equal(w.headers.get('content-type'), 'application/octet-stream');
  assert.deepEqual(new Uint8Array(await w.arrayBuffer()), m.weightBytes);
  assert.equal((await getModel(new Request(`${base}/api/get-model?part=weights&version=../x`), ctx())).status, 400);

  // The first lock was used up. A stale second save (still thinking the base is null) is refused.
  assert.equal((await send(payload())).status, 409);

  // A second training round builds on the first version.
  const lockC = await (await trainingLock(postJson('/api/training-lock', { action: 'acquire' }), ctx())).json();
  const second = await send(payload({ lockToken: lockC.token, baseVersion: version }));
  assert.equal(second.status, 201);
  assert.notEqual((await second.json()).version, version);
});

test('deleting needs the admin passcode', async () => {
  const del = (obj, token) => deleteData(postJson('/api/delete-data', obj, token ? { 'x-admin-token': token } : {}), ctx());
  delete process.env.ADMIN_TOKEN;
  assert.equal((await del({ type: 'category', category: 'book' }, 'anything')).status, 403, 'disabled without ADMIN_TOKEN');

  process.env.ADMIN_TOKEN = 'secret-passcode';
  assert.equal((await del({ type: 'category', category: 'book' })).status, 401);
  assert.equal((await del({ type: 'category', category: 'book' }, 'wrong')).status, 401);
  assert.equal((await del({ type: 'category', category: '../x' }, 'secret-passcode')).status, 400);

  const list = await (await listSamples(new Request(base + '/api/list-samples'), ctx())).json();
  assert.equal(list.server.deleteEnabled, true);
  const wb = list.categories.find((c) => c.slug === 'water-bottle');
  const one = await del({ type: 'sample', category: 'water-bottle', id: wb.sampleIds[0] }, 'secret-passcode');
  assert.equal((await one.json()).remaining, 2);
  const gone = await del({ type: 'category', category: 'book' }, 'secret-passcode');
  assert.equal((await gone.json()).deleted, 3);
  const after = await (await listSamples(new Request(base + '/api/list-samples'), ctx())).json();
  assert.deepEqual(after.categories.map((c) => [c.slug, c.count]), [['water-bottle', 2]]);
  delete process.env.ADMIN_TOKEN;
});

test('protected training: passcode required when REQUIRE_TOKEN_FOR_TRAINING=true', async () => {
  process.env.ADMIN_TOKEN = 'pw';
  process.env.REQUIRE_TOKEN_FOR_TRAINING = 'true';
  const without = await trainingLock(postJson('/api/training-lock', { action: 'acquire' }), ctx());
  assert.equal(without.status, 401);
  delete process.env.ADMIN_TOKEN;
  delete process.env.REQUIRE_TOKEN_FOR_TRAINING;
});

test('rate limit: too many uploads from one visitor get a 429', async () => {
  const same = { ip: '203.0.113.9' };
  let last;
  for (let i = 0; i <= RATE_LIMITS.upload.limit; i++) {
    last = await saveSample(post('/api/save-sample?category=Spam', new Uint8Array(0)), same);
  }
  assert.equal(last.status, 429);
  assert.ok(Number(last.headers.get('retry-after')) > 0);
});
