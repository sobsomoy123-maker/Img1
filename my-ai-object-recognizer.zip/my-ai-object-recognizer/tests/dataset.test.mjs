import test from 'node:test';
import assert from 'node:assert/strict';
import { classWeights, splitDataset } from '../src/dataset.js';

const ids = (prefix, n) => Array.from({ length: n }, (_, i) => `${prefix}${String(i).padStart(2, '0')}`);

test('splitDataset skips tiny categories and holds out 20% when there are enough images', () => {
  const split = splitDataset([
    { slug: 'pen', name: 'Pen', sampleIds: ids('b', 10) },
    { slug: 'book', name: 'Book', sampleIds: ids('a', 5) },
    { slug: 'cup', name: 'Cup', sampleIds: ids('c', 3) },
    { slug: 'tiny', name: 'Tiny', sampleIds: ids('d', 2) },
  ]);
  assert.deepEqual(split.classes.map((c) => c.slug), ['book', 'cup', 'pen']);
  assert.deepEqual(split.skipped, [{ slug: 'tiny', name: 'Tiny', count: 2 }]);
  const countOf = (arr, slug) => arr.filter((x) => x.slug === slug).length;
  assert.equal(countOf(split.val, 'book'), 1);
  assert.equal(countOf(split.val, 'pen'), 2);
  assert.equal(countOf(split.val, 'cup'), 0, 'too few images to hold any back');
  assert.equal(split.train.length + split.val.length, 18);
  const keys = [...split.train, ...split.val].map((x) => `${x.slug}/${x.id}`);
  assert.equal(new Set(keys).size, keys.length, 'no image is used twice');
  assert.deepEqual(splitDataset([{ slug: 'pen', name: 'Pen', sampleIds: ids('b', 10) }]).val, splitDataset([{ slug: 'pen', name: 'Pen', sampleIds: ids('b', 10) }]).val, 'split is repeatable');
});

test('classWeights favours smaller categories', () => {
  const train = [...Array(9).fill({ classIndex: 0 }), { classIndex: 1 }];
  const w = classWeights(train, 2);
  assert.ok(w[1] > w[0]);
  assert.ok(Math.abs(w[0] * 9 + w[1] * 1 - 10) < 1e-9);
});
