// The full "Retrain Model" workflow, step by step.
import { TRAINING } from '../netlify/lib/config.mjs';
import { passesAccuracyGate } from '../netlify/lib/validate.mjs';
import * as api from './api.js';
import { classWeights, splitDataset } from './dataset.js';
import { blobToImage } from './images.js';
import { embedImage, loadBase, tf } from './ml.js';

// Features of images already seen in this page session (saves time on the next retrain).
const featureCache = new Map();

async function featuresFor(item) {
  const key = `${item.slug}/${item.id}`;
  if (featureCache.has(key)) return featureCache.get(key);
  const blob = await api.fetchSampleBlob(item.slug, item.id);
  const img = await blobToImage(blob);
  const features = await embedImage(img);
  featureCache.set(key, features);
  return features;
}

/** A small classifier that sits on top of MobileNet's 1,280 numbers. */
function buildClassifier(featureSize, numClasses) {
  const model = tf.sequential();
  model.add(
    tf.layers.dense({
      inputShape: [featureSize],
      units: TRAINING.hiddenUnits,
      activation: 'relu',
      kernelRegularizer: tf.regularizers.l2({ l2: 0.001 }),
    }),
  );
  model.add(tf.layers.dropout({ rate: TRAINING.dropout }));
  model.add(tf.layers.dense({ units: numClasses, activation: 'softmax' }));
  model.compile({ optimizer: tf.train.adam(TRAINING.learningRate), loss: 'categoricalCrossentropy', metrics: ['accuracy'] });
  return model;
}

function stackFeatures(items, vectors, featureSize) {
  const flat = new Float32Array(items.length * featureSize);
  vectors.forEach((v, i) => flat.set(v, i * featureSize));
  return tf.tensor2d(flat, [items.length, featureSize]);
}

function toBytes(weightData) {
  if (weightData instanceof ArrayBuffer) return new Uint8Array(weightData);
  if (ArrayBuffer.isView(weightData)) return new Uint8Array(weightData.buffer, weightData.byteOffset, weightData.byteLength);
  if (Array.isArray(weightData)) {
    const parts = weightData.map(toBytes);
    const out = new Uint8Array(parts.reduce((n, p) => n + p.byteLength, 0));
    let offset = 0;
    for (const p of parts) {
      out.set(p, offset);
      offset += p.byteLength;
    }
    return out;
  }
  throw new Error('The trained model has no weights to save.');
}

function bytesToBase64(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) binary += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(binary);
}

/**
 * Trains a new model from every saved image and saves it ONLY if it passes the accuracy rule.
 * onStatus(text) and onProgress(0-100) update the screen. Throws an Error with a readable message on failure.
 */
export async function trainModel({ onStatus = () => {}, onProgress = () => {} } = {}) {
  let lock = null;
  let model = null;
  const tensors = [];

  try {
    onProgress(2);
    onStatus('Checking that nobody else is training…');
    lock = await api.acquireLock();

    onStatus('Loading MobileNet (the pretrained eyes)…');
    onProgress(5);
    await loadBase();

    onStatus('Reading the saved training images list…');
    const [{ model: current }, library] = await Promise.all([api.getModel(), api.listSamples()]);
    const baseVersion = current?.version ?? null;
    const split = splitDataset(library.categories);
    if (split.classes.length < TRAINING.minCategories) {
      throw new Error(
        `Training needs at least ${TRAINING.minCategories} categories with ${TRAINING.minSamplesPerCategory} or more images each. ` +
          'Add more images in "Teach the AI" first.',
      );
    }

    // 1. Turn every image into numbers with MobileNet.
    const all = [...split.train, ...split.val];
    const vectors = new Map();
    for (let i = 0; i < all.length; i++) {
      onStatus(`Looking at image ${i + 1} of ${all.length}…`);
      onProgress(8 + (52 * i) / all.length);
      vectors.set(all[i], await featuresFor(all[i]));
      if (i % 4 === 3) await tf.nextFrame(); // keeps the page responsive
    }
    const featureSize = vectors.get(all[0]).length;
    if (![...vectors.values()].every((v) => v.length === featureSize)) throw new Error('The image features have different sizes.');

    // 2. Train on the training images.
    const numClasses = split.classes.length;
    const xsTrain = stackFeatures(split.train, split.train.map((t) => vectors.get(t)), featureSize);
    const ysTrain = tf.tidy(() => tf.cast(tf.oneHot(tf.tensor1d(split.train.map((t) => t.classIndex), 'int32'), numClasses), 'float32'));
    tensors.push(xsTrain, ysTrain);
    model = buildClassifier(featureSize, numClasses);
    const epochs = TRAINING.epochs;
    await model.fit(xsTrain, ysTrain, {
      epochs,
      batchSize: Math.min(TRAINING.batchSize, split.train.length),
      shuffle: true,
      classWeight: classWeights(split.train, numClasses),
      callbacks: {
        onEpochEnd: async (epoch, logs) => {
          const acc = Math.round(100 * (logs?.acc ?? logs?.accuracy ?? 0));
          onStatus(`Learning… round ${epoch + 1} of ${epochs} (${acc}% right on training images)`);
          onProgress(60 + (30 * (epoch + 1)) / epochs);
          await tf.nextFrame();
        },
      },
    });

    // 3. Test on images the model never trained on (or, if there are too few images, on the training images).
    onStatus('Testing the new model…');
    onProgress(91);
    const testItems = split.val.length ? split.val : split.train;
    const xsTest = split.val.length ? stackFeatures(testItems, testItems.map((t) => vectors.get(t)), featureSize) : xsTrain;
    if (xsTest !== xsTrain) tensors.push(xsTest);
    const predictedTensor = tf.tidy(() => model.predict(xsTest).argMax(-1));
    const predicted = await predictedTensor.data();
    predictedTensor.dispose();
    const correct = testItems.reduce((n, item, i) => n + (predicted[i] === item.classIndex ? 1 : 0), 0);
    const metrics = {
      evaluatedOn: split.val.length ? 'held-out' : 'training',
      accuracy: correct / testItems.length,
      heldOutSamples: split.val.length,
      trainSamples: split.train.length,
      epochs,
    };
    const gate = passesAccuracyGate(metrics);
    if (!gate.ok) throw new Error(gate.message);

    // 4. Send the tested model to the server. The server checks it again before it becomes active.
    onStatus('Saving the new model…');
    onProgress(94);
    let artifacts = null;
    await model.save(
      tf.io.withSaveHandler(async (a) => {
        artifacts = a;
        return { modelArtifactsInfo: { dateSaved: new Date(), modelTopologyType: 'JSON' } };
      }),
    );
    const saved = await api.saveModel({
      lockToken: lock.token,
      baseVersion,
      labels: split.classes.map((c) => c.slug),
      featureSize,
      metrics,
      modelArtifacts: {
        modelTopology: artifacts.modelTopology,
        weightSpecs: artifacts.weightSpecs,
        generatedBy: artifacts.generatedBy ?? '',
      },
      weightsBase64: bytesToBase64(toBytes(artifacts.weightData)),
    });
    onProgress(100);
    return { version: saved.version, metrics, classes: split.classes, skipped: split.skipped };
  } finally {
    tensors.forEach((t) => t.dispose());
    if (model) model.dispose();
    if (lock) await api.releaseLock(lock.token).catch(() => {});
  }
}
