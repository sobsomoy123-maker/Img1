// Decides which saved images are used for learning and which are held back for testing.
// No TensorFlow here, so it is easy to test.
import { TRAINING } from '../netlify/lib/config.mjs';

/**
 * categories: [{ slug, name, sampleIds: [...] }]  (from /api/list-samples)
 * Returns the classes (in the order the model will output them), the training items,
 * the held-out test items, and the categories that were skipped for having too few images.
 */
export function splitDataset(categories, rules = TRAINING) {
  const usable = categories.filter((c) => c.sampleIds.length >= rules.minSamplesPerCategory);
  const skipped = categories
    .filter((c) => c.sampleIds.length < rules.minSamplesPerCategory)
    .map((c) => ({ slug: c.slug, name: c.name, count: c.sampleIds.length }));
  usable.sort((a, b) => (a.slug < b.slug ? -1 : 1));

  const classes = usable.map((c) => ({ slug: c.slug, name: c.name, samples: c.sampleIds.length }));
  const train = [];
  const val = [];
  usable.forEach((c, classIndex) => {
    // Image ids are hashes, so sorting them gives a fixed, "random-looking" order.
    const ids = [...c.sampleIds].sort();
    const heldOut = ids.length >= rules.heldOutFromSamples ? Math.max(1, Math.round(ids.length * rules.heldOutFraction)) : 0;
    ids.forEach((id, i) => (i < heldOut ? val : train).push({ slug: c.slug, id, classIndex }));
  });
  return { classes, train, val, skipped };
}

/** Gives small categories a bigger voice so one big category cannot drown them out. */
export function classWeights(trainItems, numClasses) {
  const counts = new Array(numClasses).fill(0);
  trainItems.forEach((t) => counts[t.classIndex]++);
  const weights = {};
  counts.forEach((n, i) => {
    weights[i] = n > 0 ? trainItems.length / (numClasses * n) : 1;
  });
  return weights;
}
