// Talks to the Netlify Functions (/api/...). Every error becomes a readable Error message.
const ADMIN_KEY = 'recognizerAdminToken';

export const getAdminToken = () => {
  try {
    return sessionStorage.getItem(ADMIN_KEY) || '';
  } catch {
    return '';
  }
};

export const setAdminToken = (value) => {
  try {
    if (value) sessionStorage.setItem(ADMIN_KEY, value);
    else sessionStorage.removeItem(ADMIN_KEY);
  } catch {
    /* storage can be blocked; the passcode then only lasts for this click */
  }
};

const adminHeaders = () => {
  const token = getAdminToken();
  return token ? { 'x-admin-token': token } : {};
};

async function send(path, options) {
  let res;
  try {
    res = await fetch(path, options);
  } catch {
    throw new Error('Cannot reach the server. Check your internet connection and try again.');
  }
  if (res.ok) return res;
  let message = `The server answered with an error (${res.status}).`;
  if ((res.headers.get('content-type') || '').includes('application/json')) {
    const data = await res.json().catch(() => null);
    if (data?.error) message = data.error;
  } else if (res.status === 404) {
    message = 'The server functions were not found. When testing on your computer, start the site with "npm run dev" (not plain Vite).';
  }
  throw new Error(message);
}

const getJson = async (path) => (await send(path, { cache: 'no-store' })).json();
const postJson = async (path, body, headers = {}) =>
  (await send(path, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body) })).json();

export const listSamples = () => getJson('/api/list-samples');

export const sampleUrl = (slug, id) => `/api/get-sample?category=${encodeURIComponent(slug)}&id=${encodeURIComponent(id)}`;

export const fetchSampleBlob = async (slug, id) => (await send(sampleUrl(slug, id))).blob();

export async function uploadSample(categoryName, blob) {
  const res = await send(`/api/save-sample?category=${encodeURIComponent(categoryName)}`, {
    method: 'POST',
    headers: { 'content-type': blob.type || 'image/jpeg' },
    body: blob,
  });
  return res.json();
}

export const getModel = () => getJson('/api/get-model');
export const getWeights = async (url) => (await send(url)).arrayBuffer();

export const acquireLock = () => postJson('/api/training-lock', { action: 'acquire' }, adminHeaders());
export const releaseLock = (token) => postJson('/api/training-lock', { action: 'release', token });
export const saveModel = (payload) => postJson('/api/save-model', payload, adminHeaders());

export const deleteSample = (category, id) => postJson('/api/delete-data', { type: 'sample', category, id }, adminHeaders());
export const deleteCategory = (category) => postJson('/api/delete-data', { type: 'category', category }, adminHeaders());
