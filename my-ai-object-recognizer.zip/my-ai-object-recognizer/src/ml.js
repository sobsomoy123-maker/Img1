// The machine-learning parts that work with pictures: MobileNet (pretrained) and our small classifier.
import * as tf from '@tensorflow/tfjs';
import * as mobilenet from '@tensorflow-models/mobilenet';

export { tf };

let basePromise = null;

/** Loads MobileNet once. It is the "pretrained eyes": it turns a picture into 1,280 numbers. */
export function loadBase() {
  if (!basePromise) {
    basePromise = (async () => {
      await tf.ready();
      // Advanced (optional): host the MobileNet files yourself and set VITE_MOBILENET_MODEL_URL.
      const customUrl = import.meta.env?.VITE_MOBILENET_MODEL_URL;
      return mobilenet.load({ version: 2, alpha: 1.0, ...(customUrl ? { modelUrl: customUrl } : {}) });
    })().catch((err) => {
      basePromise = null; // allow another try
      throw err;
    });
  }
  return basePromise;
}

/** picture (img, canvas or video) -> Float32Array of features */
export async function embedImage(source) {
  const base = await loadBase();
  const tensor = base.infer(source, true);
  try {
    return new Float32Array(await tensor.data());
  } finally {
    tensor.dispose();
  }
}

/** features -> list of probabilities, one per category */
export async function predictProbs(classifier, features) {
  const input = tf.tensor2d(features, [1, features.length]);
  const output = classifier.predict(input);
  try {
    return Array.from(await output.data());
  } finally {
    input.dispose();
    output.dispose();
  }
}

export function loadClassifier(modelArtifacts, weightData) {
  return tf.loadLayersModel(
    tf.io.fromMemory({
      modelTopology: modelArtifacts.modelTopology,
      weightSpecs: modelArtifacts.weightSpecs,
      weightData,
    }),
  );
}
