// The page itself: buttons, camera, uploads, recognition, dashboard and library.
import { TRAINING } from '../netlify/lib/config.mjs';
import { validateCategoryName } from '../netlify/lib/validate.mjs';
import * as api from './api.js';
import { blobToImage, fileToJpegBlob, videoFrameToJpeg } from './images.js';
import { embedImage, loadBase, loadClassifier, predictProbs } from './ml.js';
import { trainModel } from './train.js';

const $ = (id) => document.getElementById(id);
const $$ = (selector) => [...document.querySelectorAll(selector)];
const MAX_PENDING = 40;

/** Tiny helper to build HTML safely (it never turns text into HTML). */
function h(tag, props = {}, ...children) {
  const el = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (value === null || value === undefined || value === false) continue;
    if (key === 'class') el.className = value;
    else if (key.startsWith('on')) el.addEventListener(key.slice(2), value);
    else el.setAttribute(key, value === true ? '' : value);
  }
  el.append(...children.flat().filter((c) => c !== null && c !== undefined && c !== false));
  return el;
}

const state = {
  categories: [],
  server: { deleteEnabled: false, trainingProtected: false },
  stream: null,
  pending: [],
  pendingCounter: 0,
  uploading: false,
  training: false,
  recognizing: false,
  baseReady: false,
  baseError: false,
  modelInfo: null,
  classifier: null,
  lastProbs: null,
  threshold: TRAINING.unknownThreshold * 100,
};

// ---------- Small helpers ----------

const formatDate = (iso) => (iso ? new Date(iso).toLocaleString() : 'Never');
const plural = (n, word) => `${n} ${word}${n === 1 ? '' : 's'}`;
const categoryCount = (n) => (n === 1 ? '1 category' : `${n} categories`);

function showGlobalError(message) {
  const box = $('global-error');
  box.textContent = message;
  box.hidden = false;
}
const clearGlobalError = () => {
  $('global-error').hidden = true;
};

function isBusy() {
  return state.uploading || state.training;
}

// ---------- Status pill, buttons and warnings ----------

function updateUi() {
  const pill = $('model-pill');
  if (state.baseError) pill.textContent = 'The AI engine could not load. Reload the page.';
  else if (!state.baseReady) pill.textContent = 'Loading the AI engine (first visit downloads about 14 MB)…';
  else if (!state.modelInfo) pill.textContent = 'No trained model yet';
  else pill.textContent = `Model ready · ${categoryCount(state.modelInfo.classes.length)}`;

  const camOn = Boolean(state.stream);
  $$('.js-cam-start').forEach((b) => (b.disabled = camOn));
  $$('.js-cam-stop').forEach((b) => (b.disabled = !camOn));
  $('cam-placeholder').hidden = camOn;
  $('btn-capture').disabled = !camOn || state.uploading;
  $('btn-recognize').disabled = !camOn || !state.classifier || state.recognizing;
  $('predict-file').disabled = state.recognizing;

  $('btn-add-training').disabled = state.pending.length === 0 || isBusy();
  $('btn-clear-pending').disabled = state.pending.length === 0 || state.uploading;
  $('btn-retrain').disabled = isBusy();
  $('btn-retrain').textContent = state.training ? 'Training…' : 'Retrain Model';
  renderModelWarning();
}

function renderModelWarning() {
  const box = $('model-warning');
  const total = state.categories.length;
  let text = '';
  if (!state.classifier && total > 0) {
    text = 'There is no trained model yet. Press "Retrain Model" in the Training Dashboard to teach the AI your categories.';
  } else if (!state.classifier) {
    text = 'There is no trained model yet. Add a few categories in "Teach the AI", then retrain.';
  } else {
    const known = new Set(state.modelInfo.classes.map((c) => c.slug));
    const fresh = state.categories.filter((c) => !known.has(c.slug) && c.count >= TRAINING.minSamplesPerCategory);
    if (fresh.length) {
      text = `New since the last training: ${fresh.map((c) => c.name).join(', ')}. Press "Retrain Model" so the AI can recognize them.`;
    }
  }
  box.textContent = text;
  box.hidden = !text;
}

function renderStats() {
  const images = state.categories.reduce((sum, c) => sum + c.count, 0);
  $('stat-categories').textContent = String(state.categories.length);
  $('stat-images').textContent = String(images);
  const info = state.modelInfo;
  $('stat-model').textContent = info ? categoryCount(info.classes.length) : 'None yet';
  $('stat-trained-at').textContent = info ? formatDate(info.createdAt) : 'Never';
  if (info?.metrics) {
    const pct = Math.round(info.metrics.accuracy * 100);
    $('stat-accuracy').textContent =
      info.metrics.evaluatedOn === 'held-out' ? `${pct}% on ${plural(info.metrics.heldOutSamples, 'unseen image')}` : `${pct}% (training images only)`;
  } else {
    $('stat-accuracy').textContent = '–';
  }

  const ready = state.categories.filter((c) => c.count >= TRAINING.minSamplesPerCategory);
  const notReady = state.categories.filter((c) => c.count < TRAINING.minSamplesPerCategory);
  let hint = `Training needs ${TRAINING.minCategories} or more categories with at least ${TRAINING.minSamplesPerCategory} images each. `;
  hint += `Ready now: ${ready.length}.`;
  if (notReady.length) hint += ` Need more images: ${notReady.map((c) => `${c.name} (${c.count})`).join(', ')}.`;
  $('train-hint').textContent = hint;
}

// ---------- Library ----------

async function refreshLibrary() {
  const data = await api.listSamples();
  state.categories = data.categories;
  state.server = data.server;
  renderLibrary();
  renderStats();
  const list = $('category-list');
  list.replaceChildren(...state.categories.map((c) => h('option', { value: c.name })));
  updateUi();
}

function requireAdminToken() {
  if (api.getAdminToken()) return true;
  alert('Enter the admin passcode first. You can find the box in the Training Dashboard, under "Admin passcode".');
  return false;
}

async function deleteAndRefresh(action) {
  try {
    await action();
    clearGlobalError();
    await refreshLibrary();
  } catch (err) {
    showGlobalError(err.message);
  }
}

function categoryCard(cat) {
  const inModel = state.modelInfo?.classes.some((c) => c.slug === cat.slug);
  const needed = TRAINING.minSamplesPerCategory - cat.count;
  const status =
    needed > 0 ? `Needs ${plural(needed, 'more image')} before training` : inModel ? 'In the active model' : 'Not in the model yet. Retrain.';

  const thumbs = cat.sampleIds.slice(0, 6).map((id) =>
    h(
      'div',
      { class: 'thumb' },
      h('img', { src: api.sampleUrl(cat.slug, id), alt: `Example of ${cat.name}`, loading: 'lazy' }),
      state.server.deleteEnabled &&
        h('button', {
          type: 'button',
          class: 'thumb-x',
          'aria-label': `Delete this ${cat.name} image`,
          title: 'Delete this image',
          onclick: () => {
            if (requireAdminToken() && confirm('Delete this image? This cannot be undone.')) {
              deleteAndRefresh(() => api.deleteSample(cat.slug, id));
            }
          },
        }, '×'),
    ),
  );
  const more = cat.count - thumbs.length;

  return h(
    'article',
    { class: 'card' },
    h('div', { class: 'card-head' }, h('h3', {}, cat.name), h('span', { class: 'count' }, plural(cat.count, 'image'))),
    h('p', { class: `small ${needed > 0 ? 'warn' : ''}` }, status),
    h('div', { class: 'thumbs thumbs-tight' }, ...thumbs, more > 0 && h('span', { class: 'more' }, `+${more} more`)),
    h(
      'div',
      { class: 'row' },
      h('button', {
        type: 'button',
        class: 'btn',
        onclick: () => {
          $('category-input').value = cat.name;
          $('teach').scrollIntoView({ behavior: 'smooth', block: 'start' });
          $('category-input').focus({ preventScroll: true });
        },
      }, 'Add more images'),
      state.server.deleteEnabled &&
        h('button', {
          type: 'button',
          class: 'btn btn-danger',
          onclick: () => {
            if (requireAdminToken() && confirm(`Delete the whole "${cat.name}" category and its ${plural(cat.count, 'image')}? This cannot be undone.`)) {
              deleteAndRefresh(() => api.deleteCategory(cat.slug));
            }
          },
        }, 'Delete category'),
    ),
  );
}

function renderLibrary() {
  $('library-empty').hidden = state.categories.length > 0;
  $('library-grid').replaceChildren(...state.categories.map(categoryCard));
  $('library-note').textContent = state.server.deleteEnabled
    ? 'Deleting images or categories needs the admin passcode. A deleted category stays in the active model until you retrain.'
    : 'Deleting is switched off on this site (the owner has not set an ADMIN_TOKEN).';
}

// ---------- Model loading ----------

function disposeClassifier() {
  if (state.classifier) state.classifier.dispose();
  state.classifier = null;
}

async function refreshModel(force = false) {
  const { model } = await api.getModel();
  if (!model) {
    disposeClassifier();
    state.modelInfo = null;
  } else if (force || !state.classifier || state.modelInfo?.version !== model.version) {
    const weights = await api.getWeights(model.weightsUrl);
    const classifier = await loadClassifier(model.modelArtifacts, weights);
    disposeClassifier();
    state.classifier = classifier;
    state.modelInfo = model;
  } else {
    state.modelInfo = model;
  }
  renderStats();
  renderLibrary();
  updateUi();
}

// ---------- Camera ----------

async function startCamera() {
  if (state.stream) return;
  if (!navigator.mediaDevices?.getUserMedia) {
    showGlobalError('This browser cannot use the camera here. Camera access needs a modern browser and a secure (https) page.');
    return;
  }
  try {
    state.stream = await navigator.mediaDevices.getUserMedia({
      video: { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } },
      audio: false,
    });
    $$('.js-cam-video').forEach((video) => {
      video.srcObject = state.stream;
      video.play().catch(() => {});
    });
    clearGlobalError();
  } catch (err) {
    const reasons = {
      NotAllowedError: 'Camera permission was blocked. Allow the camera in your browser settings, then try again.',
      NotFoundError: 'No camera was found on this device.',
      NotReadableError: 'The camera is being used by another app. Close that app and try again.',
    };
    showGlobalError(reasons[err.name] || `The camera could not start (${err.name || 'unknown error'}).`);
  }
  updateUi();
}

function stopCamera() {
  if (state.stream) state.stream.getTracks().forEach((t) => t.stop());
  state.stream = null;
  $$('.js-cam-video').forEach((video) => {
    video.srcObject = null;
  });
  updateUi();
}

// ---------- Recognition ----------

function renderResult() {
  const box = $('result');
  if (!state.lastProbs || !state.modelInfo) return;
  const classes = state.modelInfo.classes;
  const ranked = state.lastProbs.map((p, i) => ({ p, cls: classes[i] })).sort((a, b) => b.p - a.p);
  const top = ranked[0];
  const pct = Math.round(top.p * 100);
  const unknown = pct < state.threshold;

  box.classList.toggle('is-unknown', unknown);
  $('result-label').textContent = unknown ? 'Unknown' : top.cls.name;
  $('result-bar-fill').style.width = `${pct}%`;
  $('result-conf').textContent = unknown
    ? `Best guess was "${top.cls.name}" at ${pct}%, which is below your ${state.threshold}% limit.`
    : `${pct}% confident`;
  $('result-top').replaceChildren(...ranked.slice(0, 3).map((r) => h('li', {}, `${r.cls.name}: ${Math.round(r.p * 100)}%`)));
  $('result-note').textContent = unknown
    ? 'The AI is not sure. This may be an object it has not learned yet. You can teach it in "Teach the AI".'
    : 'Confidence is not a guarantee. The AI can be wrong, so double-check anything important.';
}

async function recognize(source) {
  if (!state.classifier || !state.modelInfo) {
    showGlobalError('There is no trained model yet. Add categories, then press "Retrain Model".');
    return;
  }
  state.recognizing = true;
  updateUi();
  $('result-label').textContent = 'Looking…';
  try {
    const features = await embedImage(source);
    const probs = await predictProbs(state.classifier, features);
    if (probs.length !== state.modelInfo.classes.length) throw new Error('The model and its category list do not match. Please retrain.');
    state.lastProbs = probs;
    renderResult();
    clearGlobalError();
  } catch (err) {
    $('result-label').textContent = 'Could not recognize';
    showGlobalError(err.message || 'Recognition failed.');
  } finally {
    state.recognizing = false;
    updateUi();
  }
}

async function onPredictFile(event) {
  const file = event.target.files?.[0];
  event.target.value = '';
  if (!file) return;
  try {
    const blob = await fileToJpegBlob(file);
    const preview = $('predict-preview');
    if (preview.dataset.url) URL.revokeObjectURL(preview.dataset.url);
    preview.dataset.url = URL.createObjectURL(blob);
    preview.src = preview.dataset.url;
    preview.hidden = false;
    await recognize(await blobToImage(blob));
  } catch (err) {
    showGlobalError(err.message);
  }
}

// ---------- Teach the AI: choosing photos ----------

function renderPending() {
  const grid = $('pending-grid');
  grid.replaceChildren(
    ...state.pending.map((item) =>
      h(
        'div',
        { class: 'thumb' },
        h('img', { src: item.url, alt: `Selected photo: ${item.name}` }),
        h('button', {
          type: 'button',
          class: 'thumb-x',
          'aria-label': `Remove ${item.name}`,
          title: 'Remove',
          disabled: state.uploading,
          onclick: () => removePending(item.id),
        }, '×'),
      ),
    ),
  );
  $('pending-count').textContent = state.pending.length
    ? `${plural(state.pending.length, 'photo')} ready to add. Remove any you do not want.`
    : 'No photos selected yet.';
  updateUi();
}

function addPending({ file = null, blob = null, name }) {
  if (state.pending.length >= MAX_PENDING) {
    showGlobalError(`You can prepare at most ${MAX_PENDING} photos at a time. Add these first, then choose more.`);
    return;
  }
  state.pending.push({ id: ++state.pendingCounter, file, blob, name, url: URL.createObjectURL(file || blob) });
}

function removePending(id) {
  const index = state.pending.findIndex((p) => p.id === id);
  if (index === -1) return;
  URL.revokeObjectURL(state.pending[index].url);
  state.pending.splice(index, 1);
  renderPending();
}

function onTeachFiles(event) {
  const files = [...(event.target.files ?? [])];
  event.target.value = '';
  const rejected = [];
  for (const file of files) {
    if (!file.type.startsWith('image/')) rejected.push(file.name);
    else addPending({ file, name: file.name });
  }
  if (rejected.length) showGlobalError(`These files are not images and were skipped: ${rejected.join(', ')}`);
  renderPending();
}

async function onCapture() {
  try {
    const video = document.querySelector('#teach .js-cam-video');
    const blob = await videoFrameToJpeg(video);
    addPending({ blob, name: `Camera photo ${state.pendingCounter + 1}` });
    renderPending();
  } catch (err) {
    showGlobalError(err.message);
  }
}

// ---------- Teach the AI: uploading ----------

const log = (text, isError = false) => $('upload-log').append(h('li', { class: isError ? 'error' : '' }, text));

async function onAddTraining() {
  if (isBusy() || state.pending.length === 0) return;
  const checked = validateCategoryName($('category-input').value);
  const errorBox = $('category-error');
  if (!checked.ok) {
    errorBox.textContent = checked.error;
    errorBox.hidden = false;
    $('category-input').focus();
    return;
  }
  errorBox.hidden = true;

  state.uploading = true;
  $('upload-log').replaceChildren();
  $('upload-progress').hidden = false;
  renderPending();

  const items = [...state.pending];
  let saved = 0;
  let duplicates = 0;
  let failed = 0;
  for (let i = 0; i < items.length; i++) {
    const item = items[i];
    $('upload-status').textContent = `Uploading photo ${i + 1} of ${items.length}…`;
    $('upload-progress').value = (100 * i) / items.length;
    try {
      const blob = item.blob ?? (await fileToJpegBlob(item.file));
      const result = await api.uploadSample(checked.name, blob);
      if (result.duplicate) {
        duplicates++;
        log(`${item.name}: this exact photo was already saved, so it was skipped.`);
      } else {
        saved++;
      }
      removePending(item.id);
    } catch (err) {
      failed++;
      log(`${item.name}: ${err.message}`, true);
      if (/too quickly/i.test(err.message)) {
        log('Stopped early because of the upload speed limit. Wait a minute, then press Add Training Images again.', true);
        break;
      }
    }
  }

  $('upload-progress').value = 100;
  const parts = [`${plural(saved, 'photo')} saved`];
  if (duplicates) parts.push(`${duplicates} already existed`);
  if (failed) parts.push(`${failed} failed (still in the list, so you can try again)`);
  $('upload-status').textContent = `${parts.join(', ')}.`;
  state.uploading = false;
  try {
    await refreshLibrary();
  } catch (err) {
    showGlobalError(err.message);
  }
  renderPending();
}

// ---------- Training ----------

async function onRetrain() {
  if (isBusy()) return;
  state.training = true;
  $('train-error').hidden = true;
  $('train-progress').value = 0;
  updateUi();
  try {
    const result = await trainModel({
      onStatus: (text) => ($('train-status').textContent = text),
      onProgress: (value) => ($('train-progress').value = value),
    });
    await refreshModel(true);
    await refreshLibrary();
    const pct = Math.round(result.metrics.accuracy * 100);
    const how =
      result.metrics.evaluatedOn === 'held-out'
        ? `${pct}% correct on ${plural(result.metrics.heldOutSamples, 'test image')} it had never seen`
        : `${pct}% correct on its own training images (there were too few images to keep some back for testing)`;
    let message = `Done! The new model knows ${categoryCount(result.classes.length)} and scored ${how}.`;
    if (result.skipped.length) {
      message += ` Not included (need ${TRAINING.minSamplesPerCategory}+ images): ${result.skipped.map((s) => s.name).join(', ')}.`;
    }
    $('train-status').textContent = message;
    clearGlobalError();
  } catch (err) {
    $('train-error').textContent = err.message || 'Training failed for an unknown reason.';
    $('train-error').hidden = false;
    $('train-status').textContent = 'Training stopped. Your previous model (if you had one) is still active.';
    $('train-progress').value = 0;
  } finally {
    state.training = false;
    updateUi();
  }
}

// ---------- Start up ----------

function bindEvents() {
  $$('.js-cam-start').forEach((b) => b.addEventListener('click', startCamera));
  $$('.js-cam-stop').forEach((b) => b.addEventListener('click', stopCamera));
  $('btn-recognize').addEventListener('click', () => recognize(document.querySelector('#live .js-cam-video')));
  $('predict-file').addEventListener('change', onPredictFile);
  $('btn-capture').addEventListener('click', onCapture);
  $('teach-files').addEventListener('change', onTeachFiles);
  $('btn-add-training').addEventListener('click', onAddTraining);
  $('btn-clear-pending').addEventListener('click', () => {
    [...state.pending].forEach((p) => removePending(p.id));
  });
  $('btn-retrain').addEventListener('click', onRetrain);
  $('btn-refresh').addEventListener('click', () => reload(true));
  $('threshold').addEventListener('input', (event) => {
    state.threshold = Number(event.target.value);
    $('threshold-out').textContent = `${state.threshold}%`;
    renderResult();
  });
  $('threshold').value = String(state.threshold);
  $('threshold-out').textContent = `${state.threshold}%`;
  $('admin-token').value = api.getAdminToken();
  $('admin-token').addEventListener('input', (event) => api.setAdminToken(event.target.value.trim()));
  $('category-input').addEventListener('input', () => ($('category-error').hidden = true));
  window.addEventListener('pagehide', stopCamera);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden && !isBusy()) reload(false);
  });
}

async function reload(showErrors) {
  try {
    await refreshLibrary();
    await refreshModel();
    if (showErrors) clearGlobalError();
  } catch (err) {
    if (showErrors) showGlobalError(err.message);
  }
}

async function init() {
  bindEvents();
  updateUi();
  loadBase()
    .then(() => (state.baseReady = true))
    .catch((err) => {
      state.baseError = true;
      showGlobalError(`The pretrained MobileNet could not be downloaded: ${err.message}. Check your internet connection and reload.`);
    })
    .finally(updateUi);
  try {
    await refreshLibrary();
    await refreshModel();
  } catch (err) {
    showGlobalError(err.message);
  }
}

init();
