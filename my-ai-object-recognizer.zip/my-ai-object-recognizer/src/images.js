// Turns camera frames and chosen files into small JPEG pictures that are safe to upload.
import { LIMITS, TRAINING } from '../netlify/lib/config.mjs';

const MAX_INPUT_BYTES = 25 * 1024 * 1024;

export async function blobToImage(blob) {
  const url = URL.createObjectURL(blob);
  try {
    const img = new Image();
    img.src = url;
    if (img.decode) {
      await img.decode();
    } else {
      await new Promise((resolve, reject) => {
        img.onload = resolve;
        img.onerror = reject;
      });
    }
    return img;
  } catch {
    throw new Error('This image could not be opened. Try a normal JPEG or PNG photo.');
  } finally {
    URL.revokeObjectURL(url);
  }
}

async function drawToJpeg(source, width, height) {
  if (Math.min(width, height) < LIMITS.minImageSide) {
    throw new Error(`The image is too small. Each side must be at least ${LIMITS.minImageSide} pixels.`);
  }
  const scale = Math.min(1, TRAINING.uploadMaxSide / Math.max(width, height));
  const canvas = document.createElement('canvas');
  canvas.width = Math.max(1, Math.round(width * scale));
  canvas.height = Math.max(1, Math.round(height * scale));
  canvas.getContext('2d').drawImage(source, 0, 0, canvas.width, canvas.height);
  for (const quality of [0.88, 0.75, 0.6, 0.45]) {
    const blob = await new Promise((resolve) => canvas.toBlob(resolve, 'image/jpeg', quality));
    if (blob && blob.size <= LIMITS.maxImageBytes) return blob;
  }
  throw new Error('This image is too detailed to shrink below the size limit.');
}

/** Any picture the browser can open -> a JPEG of at most 640 pixels. */
export async function fileToJpegBlob(file) {
  if (!file.type || !file.type.startsWith('image/')) throw new Error(`"${file.name}" is not an image file.`);
  if (file.size > MAX_INPUT_BYTES) throw new Error(`"${file.name}" is larger than 25 MB.`);
  let bitmap = null;
  try {
    bitmap = await createImageBitmap(file, { imageOrientation: 'from-image' });
  } catch {
    bitmap = null; // some browsers do not support the option; fall back below
  }
  if (bitmap) {
    try {
      return await drawToJpeg(bitmap, bitmap.width, bitmap.height);
    } finally {
      bitmap.close();
    }
  }
  const img = await blobToImage(file);
  return drawToJpeg(img, img.naturalWidth, img.naturalHeight);
}

export async function videoFrameToJpeg(video) {
  if (!video.videoWidth || !video.videoHeight) throw new Error('The camera is not ready yet. Wait a second and try again.');
  return drawToJpeg(video, video.videoWidth, video.videoHeight);
}
