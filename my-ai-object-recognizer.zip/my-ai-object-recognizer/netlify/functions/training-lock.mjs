// POST /api/training-lock   { action: "acquire" } or { action: "release", token }
// Only one person can train at a time. The lock expires by itself after 10 minutes.
import { HttpError, enforceRate, json, readJson, requireMethod, requireTrainingPermission, route } from '../lib/http.mjs';
import { acquireLock, releaseLock } from '../lib/storage.mjs';

export default route(async (req, context) => {
  requireMethod(req, 'POST');
  await enforceRate(req, context, 'lock');
  const body = await readJson(req, 2_000);

  if (body.action === 'acquire') {
    requireTrainingPermission(req);
    const lock = await acquireLock();
    return json({ ok: true, ...lock });
  }
  if (body.action === 'release') {
    await releaseLock(body.token);
    return json({ ok: true });
  }
  throw new HttpError(400, 'Unknown action.');
});

export const config = { path: '/api/training-lock' };
