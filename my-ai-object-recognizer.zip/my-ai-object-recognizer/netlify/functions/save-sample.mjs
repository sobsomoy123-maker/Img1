// POST /api/save-sample?category=Bottle   (body = one JPEG or PNG image)
import { LIMITS } from '../lib/config.mjs';
import { HttpError, enforceRate, json, readBody, requireMethod, route } from '../lib/http.mjs';
import { saveSample } from '../lib/storage.mjs';
import { checkImageSize, inspectImage, sha256Hex, validateCategoryName } from '../lib/validate.mjs';

export default route(async (req, context) => {
  requireMethod(req, 'POST');
  await enforceRate(req, context, 'upload');

  const cat = validateCategoryName(new URL(req.url).searchParams.get('category') ?? '');
  if (!cat.ok) throw new HttpError(400, cat.error);

  const bytes = await readBody(req, LIMITS.maxImageBytes);
  const info = inspectImage(bytes); // looks at the real file bytes, not at the claimed type
  if (!info.ok) throw new HttpError(415, info.error);
  const size = checkImageSize(info);
  if (!size.ok) throw new HttpError(422, size.error);

  const id = await sha256Hex(bytes); // same picture = same id, so duplicates are never stored twice
  const result = await saveSample({ cat, bytes, info, id });
  return json({ ok: true, ...result }, result.duplicate ? 200 : 201);
});

export const config = { path: '/api/save-sample' };
