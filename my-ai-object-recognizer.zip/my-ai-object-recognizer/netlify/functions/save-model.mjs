// POST /api/save-model  -> checks a newly trained model and, only if every check passes, makes it the active model.
import { LIMITS, TRAINING } from '../lib/config.mjs';
import {
  HttpError, enforceRate, json, readJson, requireMethod, requireTrainingPermission, route,
} from '../lib/http.mjs';
import { getActiveModel, listCategories, lockIsHeld, releaseLock, saveModelVersion } from '../lib/storage.mjs';
import { isValidSlug, passesAccuracyGate, validateModelArtifacts } from '../lib/validate.mjs';

const isCount = (v) => Number.isInteger(v) && v >= 0 && v <= 1_000_000;

export default route(async (req, context) => {
  requireMethod(req, 'POST');
  await enforceRate(req, context, 'model');
  requireTrainingPermission(req);

  const body = await readJson(req, LIMITS.maxModelRequestBytes);
  const { lockToken, baseVersion, labels, featureSize, metrics, modelArtifacts, weightsBase64 } = body;

  // 1. You must hold the training lock.
  if (!(await lockIsHeld(lockToken))) {
    throw new HttpError(409, 'Your training session expired or was replaced. Please retrain.');
  }

  // 2. Nobody saved a newer model while you were training.
  const active = await getActiveModel();
  if ((active?.version ?? null) !== (baseVersion ?? null)) {
    throw new HttpError(409, 'Another model was saved while you were training. Reload the page and retrain.');
  }

  // 3. Labels must be real categories that still have enough images.
  if (!Array.isArray(labels) || labels.length < TRAINING.minCategories || labels.length > LIMITS.maxCategories) {
    throw new HttpError(400, 'The model needs at least two categories.');
  }
  if (new Set(labels).size !== labels.length || !labels.every(isValidSlug)) throw new HttpError(400, 'Invalid category list.');
  const categories = await listCategories();
  const bySlug = new Map(categories.map((c) => [c.slug, c]));
  for (const slug of labels) {
    const c = bySlug.get(slug);
    if (!c || c.count < TRAINING.minSamplesPerCategory) {
      throw new HttpError(409, 'The library changed while you were training (a category was removed or has too few images). Please retrain.');
    }
  }

  // 4. The accuracy rule is checked again on the server.
  if (!metrics || typeof metrics !== 'object') throw new HttpError(400, 'The model has no test results.');
  const gate = passesAccuracyGate(metrics);
  if (!gate.ok) throw new HttpError(422, gate.message);

  // 5. The model files must be exactly the small classifier this app creates.
  if (typeof weightsBase64 !== 'string' || weightsBase64.length > LIMITS.maxModelWeightBytes * 1.4) {
    throw new HttpError(413, 'The model is too large.');
  }
  if (!modelArtifacts || typeof modelArtifacts !== 'object') throw new HttpError(400, 'The model files are missing.');
  const weightBytes = new Uint8Array(Buffer.from(weightsBase64, 'base64'));
  const checked = validateModelArtifacts(modelArtifacts, weightBytes, { labelCount: labels.length, featureSize });
  if (!checked.ok) throw new HttpError(422, `The model was rejected: ${checked.error}`);

  // 6. Save. The "active" pointer only changes after every file was written.
  const classes = labels.map((slug) => ({ slug, name: bySlug.get(slug).name, samples: bySlug.get(slug).count }));
  const savedMetrics = {
    evaluatedOn: metrics.evaluatedOn,
    accuracy: metrics.accuracy,
    heldOutSamples: isCount(metrics.heldOutSamples) ? metrics.heldOutSamples : 0,
    trainSamples: isCount(metrics.trainSamples) ? metrics.trainSamples : 0,
    epochs: isCount(metrics.epochs) ? metrics.epochs : 0,
  };
  const saved = await saveModelVersion({
    artifacts: {
      modelTopology: modelArtifacts.modelTopology,
      weightSpecs: checked.weightSpecs,
      format: 'layers-model',
      generatedBy: String(modelArtifacts.generatedBy ?? '').slice(0, 100),
      convertedBy: null,
    },
    weightBytes,
    classes,
    metrics: savedMetrics,
    featureSize,
  });
  await releaseLock(lockToken);
  return json({ ok: true, version: saved.version, createdAt: saved.createdAt }, 201);
});

export const config = { path: '/api/save-model' };
