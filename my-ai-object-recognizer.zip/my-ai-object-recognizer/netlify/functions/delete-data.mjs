// POST /api/delete-data   { type: "sample", category, id }  or  { type: "category", category }
// Needs the ADMIN_TOKEN passcode (sent in the x-admin-token header). Turned off if no ADMIN_TOKEN is set.
import {
  HttpError, adminStatus, enforceRate, isAdmin, json, readJson, requireMethod, route,
} from '../lib/http.mjs';
import { deleteCategory, deleteSample } from '../lib/storage.mjs';
import { isValidSampleId, isValidSlug } from '../lib/validate.mjs';

export default route(async (req, context) => {
  requireMethod(req, 'POST');
  await enforceRate(req, context, 'delete');
  if (!adminStatus().deleteEnabled) {
    throw new HttpError(403, 'Deleting is turned off. The site owner must set an ADMIN_TOKEN environment variable first.');
  }
  if (!isAdmin(req)) throw new HttpError(401, 'The admin passcode is missing or wrong.');

  const body = await readJson(req, 2_000);
  if (!isValidSlug(body.category)) throw new HttpError(400, 'Invalid category.');

  if (body.type === 'sample') {
    if (!isValidSampleId(body.id)) throw new HttpError(400, 'Invalid image id.');
    return json({ ok: true, ...(await deleteSample(body.category, body.id)) });
  }
  if (body.type === 'category') {
    return json({ ok: true, ...(await deleteCategory(body.category)) });
  }
  throw new HttpError(400, 'Unknown delete type.');
});

export const config = { path: '/api/delete-data' };
