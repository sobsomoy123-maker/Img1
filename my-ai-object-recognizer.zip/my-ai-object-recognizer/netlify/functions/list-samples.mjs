// GET /api/list-samples  -> every category, its image ids, and which admin features are on
import { adminStatus, json, requireMethod, route } from '../lib/http.mjs';
import { listCategories } from '../lib/storage.mjs';

export default route(async (req) => {
  requireMethod(req, 'GET');
  const categories = await listCategories();
  const totalSamples = categories.reduce((sum, c) => sum + c.count, 0);
  return json({ ok: true, categories, totalSamples, server: adminStatus() });
});

export const config = { path: '/api/list-samples' };
