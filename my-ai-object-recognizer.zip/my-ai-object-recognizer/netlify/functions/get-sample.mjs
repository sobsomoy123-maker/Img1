// GET /api/get-sample?category=<slug>&id=<sha256>  -> the image itself
// The storage key is built only from two validated parts, so nobody can read other keys.
import { HttpError, requireMethod, route } from '../lib/http.mjs';
import { getSample } from '../lib/storage.mjs';
import { isValidSampleId, isValidSlug } from '../lib/validate.mjs';

export default route(async (req) => {
  requireMethod(req, 'GET');
  const params = new URL(req.url).searchParams;
  const slug = params.get('category');
  const id = params.get('id');
  if (!isValidSlug(slug) || !isValidSampleId(id)) throw new HttpError(400, 'Invalid image address.');

  const found = await getSample(slug, id);
  if (!found) throw new HttpError(404, 'Image not found.');
  const type = found.metadata?.contentType === 'image/png' ? 'image/png' : 'image/jpeg';
  return new Response(found.data, {
    status: 200,
    headers: {
      'content-type': type,
      'x-content-type-options': 'nosniff',
      'content-security-policy': "default-src 'none'",
      // The id is the hash of the image, so this address never shows different content.
      'cache-control': 'public, max-age=31536000, immutable',
    },
  });
});

export const config = { path: '/api/get-sample' };
