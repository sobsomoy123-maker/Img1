// GET /api/get-model                        -> info + layout of the active model (or model: null)
// GET /api/get-model?part=weights&version=V -> the weight numbers of version V (binary)
import { HttpError, json, requireMethod, route } from '../lib/http.mjs';
import { getActiveModel, getModelArtifacts, getModelWeights } from '../lib/storage.mjs';
import { isValidVersion } from '../lib/validate.mjs';

export default route(async (req) => {
  requireMethod(req, 'GET');
  const params = new URL(req.url).searchParams;

  if (params.get('part') === 'weights') {
    const version = params.get('version');
    if (!isValidVersion(version)) throw new HttpError(400, 'Invalid model version.');
    const weights = await getModelWeights(version);
    if (!weights) throw new HttpError(404, 'Model weights not found.');
    return new Response(weights, {
      status: 200,
      headers: {
        'content-type': 'application/octet-stream',
        'x-content-type-options': 'nosniff',
        'cache-control': 'public, max-age=31536000, immutable', // a version never changes
      },
    });
  }

  const active = await getActiveModel();
  if (!active) return json({ ok: true, model: null });
  const artifacts = await getModelArtifacts(active.version);
  if (!artifacts) throw new HttpError(500, 'The active model files are missing. Please retrain.');
  return json({
    ok: true,
    model: {
      version: active.version,
      createdAt: active.createdAt,
      classes: active.classes,
      metrics: active.metrics,
      featureSize: active.featureSize,
      modelArtifacts: artifacts,
      weightsUrl: `/api/get-model?part=weights&version=${active.version}`,
    },
  });
});

export const config = { path: '/api/get-model' };
