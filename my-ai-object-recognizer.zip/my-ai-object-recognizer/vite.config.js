import { defineConfig } from 'vite';

// Vite builds the website (HTML, CSS, JavaScript) into the "dist" folder.
export default defineConfig({
  build: {
    outDir: 'dist',
    target: 'es2020',
    chunkSizeWarningLimit: 4000, // TensorFlow.js is large; this is normal.
  },
  server: { port: 5173, strictPort: true },
});
