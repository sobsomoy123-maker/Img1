# My AI Object Recognizer

A website that learns to recognize **your own objects** with a camera.
You teach it (Bottle, Book, Pen…), press **Retrain Model**, and it can then name what it sees.

- The AI runs **inside the visitor's browser** (TensorFlow.js + MobileNet). No Python, no paid AI service.
- Photos, category names and the trained model are saved on **Netlify Blobs**, so everyone who opens the site sees the same learned categories and the same model, even after a redeploy.
- Anyone can add photos. There is **no login** in this first version (see "Public access" below).

---

## 1. What works and what does not

**Works (checked by automated tests of the server code, see section 9):**
- Saving photos, category names, and model versions in storage; duplicate photos are not stored twice.
- Checking uploads on the server: real file type, size, picture dimensions, category name.
- Training lock (one person trains at a time), versioned models, and an "active model" that only changes after a model passes every check.
- Rate limiting, optional admin passcode for deleting, and refusal of broken or tampered model files.

**Written carefully but NOT run in a real browser by me** (I had no browser and no internet in my work environment):
- The camera, the page layout, MobileNet downloading, training in the browser, and recognition.
- `npm install`, `npm run build`, and real Netlify Blobs. Please follow the test checklist in section 8 on your own computer and on Netlify.

**Known limits (honest list):**
1. **Public write access.** Anyone can upload photos and retrain. A visitor could upload misleading photos or publish a poor model. See section 6.
2. **Training happens in the visitor's browser.** The server checks that a model file is well-formed (right layers, right sizes, normal numbers) and that it claims a good test score, but it **cannot re-train to verify the score**. A determined attacker could send a well-formed model with a made-up score. If this matters, turn on the admin passcode for training (section 5).
3. **Rate limits are "best effort".** They stop casual abuse, not a determined attacker with many IP addresses.
4. **Category names use English letters, numbers, spaces, `-` and `_` only.**
5. **Limits:** 60 photos per category, 50 categories, 1,500 photos in total, photos are shrunk to 640 pixels (JPEG).
6. **First visit downloads MobileNet (about 14 MB)** from the host used by the `@tensorflow-models/mobilenet` package. If that host is blocked or offline, the app cannot recognize anything.
7. A very small data set gives a weak model. Use at least 5 photos per category, from different angles and lighting.
8. Confidence is **not** a guarantee. The AI can be confidently wrong. Anything below your chosen confidence limit is shown as "Unknown".

---

## 2. Folder map

```
index.html                 The page (4 sections)
src/app.js                 Buttons, camera, uploads, recognition, library
src/train.js               The "Retrain Model" steps
src/ml.js                  MobileNet + using the saved classifier
src/dataset.js             Which photos train the model, which are kept for testing
src/api.js, src/images.js  Talking to the server, shrinking photos
src/style.css              Looks
netlify/functions/         The backend (7 small functions, addresses start with /api/)
netlify/lib/               Shared rules (limits, checks, storage code)
tests/                     Automated tests (run with: npm test)
netlify.toml               Netlify settings
package.json, vite.config.js, .nvmrc, .gitignore
```

---

## 3. Run it on your computer

1. **Install Node.js (LTS version)** from https://nodejs.org (click the "LTS" button). Then open a terminal (Windows: "Command Prompt" or "PowerShell"; Mac: "Terminal") and check:
   ```
   node -v
   ```
   You should see version 18.14 or higher (20 or newer is best).
2. **Extract the ZIP.** Right-click it and choose "Extract All" (Windows) or double-click it (Mac).
3. **Open a terminal in the project folder:**
   ```
   cd path/to/my-ai-object-recognizer
   ```
4. **Install the packages** (needs internet, takes a few minutes):
   ```
   npm install
   ```
5. **Start the app:**
   ```
   npm run dev
   ```
   Open **http://localhost:8888**. (This runs the Netlify CLI, which serves the page and the `/api` functions and keeps a local test copy of Blobs in a hidden `.netlify` folder.) If the CLI asks you to log in or link a site, you can usually skip that for local testing. If you see Blobs errors, update the CLI with `npm install -D netlify-cli@latest`.
6. **Run the automated tests** (no internet needed):
   ```
   npm test
   ```

The camera works on `http://localhost` and on any `https://` address, but not on plain `http://` addresses of other computers.

---

## 4. Put it on Netlify

1. **Create a GitHub repository** (https://github.com/new) and upload this project. With Git installed, in the project folder:
   ```
   git init
   git add .
   git commit -m "My AI Object Recognizer"
   git branch -M main
   git remote add origin https://github.com/YOUR-NAME/my-ai-object-recognizer.git
   git push -u origin main
   ```
2. In Netlify (https://app.netlify.com) choose **Add new project → Import an existing project → GitHub** and pick the repository.
3. The settings come from `netlify.toml`. They should show **Build command `npm run build`**, **Publish directory `dist`**, **Functions directory `netlify/functions`**. Press **Deploy**.
4. **Storage needs no setup.** Netlify Blobs is built in and works on Netlify-hosted deploys automatically.
5. When the deploy finishes, open your `https://….netlify.app` address.

Data saved with Blobs belongs to the **whole site**, so it survives new deploys. Deploy previews of the same site may read and write the same data. Check Netlify's Blobs documentation if you use deploy previews. Netlify Functions and Blobs usage counts toward your Netlify plan limits.

---

## 5. Optional settings (Environment variables)

In Netlify: **Site configuration → Environment variables**. Redeploy after changing them.

| Name | What it does |
|---|---|
| `ADMIN_TOKEN` | A secret passcode you choose (long and random). **Turns on deleting** photos and categories. Without it, deleting is disabled for everyone. Enter it in the page under *Training Dashboard → Admin passcode*. |
| `REQUIRE_TOKEN_FOR_TRAINING` | Set to `true` (together with `ADMIN_TOKEN`) so that **only people with the passcode can retrain / publish a model**. Visitors can still add photos and recognize objects. |
| `RATE_LIMIT_SALT` | Any random text. Used to scramble visitor addresses before they are stored for rate limiting. |
| `VITE_MOBILENET_MODEL_URL` | Advanced. Address of your own copy of the MobileNet files. Needed at build time. |

For local testing, create a file named `.env` in the project folder (it is not uploaded to Git), for example:
```
ADMIN_TOKEN=my-test-passcode
```

---

## 6. Public access: what is protected and what is not

**Enforced by the code (and covered by tests):**
- Only real JPEG or PNG files are accepted (the file's first bytes are checked, not its name). Size and dimensions are limited.
- Category names are checked; storage keys are built only from validated parts, so nobody can read or write other keys.
- Same picture twice is stored once (files are named by their SHA-256 fingerprint).
- Limits on images per category, categories, and total images.
- Per-visitor request limits (best effort: the counter is not perfectly exact when many requests arrive at the same moment).
- One training session at a time (a lock that expires after 10 minutes).
- A new model becomes active only if it: holds the lock, was trained on top of the currently active version, uses only existing categories, passes the accuracy rule, and has exactly the expected layers, sizes and normal numbers. The "active" pointer changes last, so a failed save never breaks the live model. The last 5 versions are kept.
- Deleting needs `ADMIN_TOKEN`.

**Not protected:** a visitor can still upload misleading photos, and (unless you set `REQUIRE_TOKEN_FOR_TRAINING`) publish a well-formed model with a made-up test score. Practical steps: set `ADMIN_TOKEN` and `REQUIRE_TOKEN_FOR_TRAINING=true`, check the Knowledge Library now and then, delete bad photos, use Netlify's own protections (site password or rate limiting on paid plans), or add a real login later.

---

## 7. How the learning works (simple version)

1. **MobileNet** is a ready-made AI that already knows how to "look" at pictures. It turns each picture into 1,280 numbers.
2. We train a **small classifier** on those numbers. It learns which numbers belong to which of your categories. This is fast and needs only a few photos.
3. About 20% of photos from categories with 5+ photos are **kept back as a test**. The model never trains on them. If it scores below 70% on them, it is **not saved** and your old model stays active. (If no category has enough photos to keep any back, the model is tested on its own training photos and must score 90%, and the page says so.)
4. The saved model is stored as versioned files in Netlify Blobs. Every visitor's browser downloads the active model and uses it.

---

## 8. Test checklist (do these yourself)

Tick each box after you try it.

- [ ] **Camera:** press *Start Camera*, allow access, see the picture. Press *Stop Camera*, the picture stops. Deny access once: you see a clear message.
- [ ] **Image upload:** upload a JPEG and a PNG in *Teach the AI*: previews appear and can be removed with ×. Choose a `.txt` file: it is refused with a message.
- [ ] **New category:** type `Bottle`, add 5 photos, press *Add Training Images*. *Knowledge Library* shows `Bottle` with 5 images. Try the name `../x`: refused.
- [ ] **Retrain with several categories:** add `Book` and `Pen` (5+ photos each), press *Retrain Model*. Progress moves, then you see a success message with a test score.
- [ ] **Previously learned categories still work:** after adding a 4th category and retraining, `Bottle` and `Book` are still recognized.
- [ ] **Recognize:** point at a Bottle, press *Recognize*: name and confidence appear. Show something unrelated and raise the "Unknown" slider: the answer becomes "Unknown".
- [ ] **Reload the page:** categories, counts, photos and the model are all still there (no retraining needed).
- [ ] **Another device:** open the site on your phone. Same categories and model. Capture a photo there and add it.
- [ ] **Persistence after a new deploy:** in Netlify press *Deploys → Trigger deploy*. After it finishes, reload the site: photos, categories and the model are still there.
- [ ] **Invalid uploads:** try a renamed `.txt` file as `.jpg`, a tiny image (under 64 pixels), and a huge photo. All are refused or shrunk, with a clear message.
- [ ] **Failed training:** with only 1 category (or categories with under 3 photos each), press *Retrain Model*: you get an error message, and the old model still works.
- [ ] **Simultaneous users:** on two devices press *Retrain Model* at the same moment. One trains, the other sees "Someone else is training right now". Upload photos from both at once: all arrive.
- [ ] **Deleting (if `ADMIN_TOKEN` is set):** without the passcode deleting is refused; with it, a photo or category is removed.

---

## 9. What I actually ran

In my work environment (no internet, so no packages could be installed) I ran:

- `node --test` → **15 automated tests, all passed.** They run the real function code against an in-memory copy of Blobs (uploads, validation, duplicates, listing, image serving, lock, model checks and rejection of tampered models, versioning, deleting with and without passcode, rate limit) and the training/test split logic.
- Syntax checks of every JavaScript file.
- A script that checks that every import resolves, every `$('id')` used by `app.js` exists in `index.html`, every CSS class used is styled, and every `/api/...` address the browser calls is served by a function.

I did **not** run: `npm install`, `npm run build`, `netlify dev`, real Netlify Blobs, any browser, the camera, MobileNet, or real training. The package versions in `package.json` come from my knowledge, not from checking the registry. If `npm install` complains about a version, tell me the message and I will fix it.

---

## 10. Troubleshooting

| Problem | Try |
|---|---|
| "The server functions were not found" | Start with `npm run dev`, not `npm run dev:vite`. |
| "The pretrained MobileNet could not be downloaded" | Check your internet; turn off ad blockers; try another network. |
| Camera does not start | Use https (or localhost), allow camera permission, close other apps that use the camera. |
| "Someone else is training right now" | Wait up to 10 minutes; the lock frees itself. |
| Training says accuracy is too low | Add more photos per category, from different angles, with clear backgrounds. |
| Deleting says "turned off" | Set `ADMIN_TOKEN` in Netlify and redeploy. |
